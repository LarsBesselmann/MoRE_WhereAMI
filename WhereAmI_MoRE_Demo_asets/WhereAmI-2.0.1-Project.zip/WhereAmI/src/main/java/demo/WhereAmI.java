package demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.management.ManagementFactory;
import java.net.InetAddress;
import java.util.Date;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.management.MBeanServer;
import javax.management.ObjectInstance;
import javax.management.ObjectName;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class WhereAmI
 */
@WebServlet("/WhereAmI")
public class WhereAmI extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public WhereAmI() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    	PrintWriter out = res.getWriter ();
    	res.setContentType("text/html");
    	out.println("<HTML><HEAD><TITLE>Where am I running?</TITLE></HEAD><BODY BGCOLOR=\"#FFFFEE\">");
    	out.println("<h1>Where Am I Running?</h1>");
        out.println("<h2><font color = \"black\">Get Server name: </h2>");
    	String name = null;
        
        String serverName = "";

        serverName = System.getProperty("wlp.server.name");
        out.println("<h2><font color = \"black\">Server Display Name: "+serverName+"</h2>");
        serverName = System.getProperty("wlp.server.name");
        out.println("<h2><font color = \"black\">Server Full Name: "+serverName+"</h2>");
 
    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}